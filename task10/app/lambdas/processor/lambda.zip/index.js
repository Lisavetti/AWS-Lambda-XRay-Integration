const AWSXRay = require('aws-xray-sdk');

const AWS = AWSXRay.captureAWS(require('aws-sdk'));

const { v4: uuidv4 } = require('uuid');

const ddb = new AWS.DynamoDB();

exports.handler = async (event) => {
    try {
        const tableName = process.env.TARGET_TABLE || 'Weather';

        const url = 'https://api.open-meteo.com/v1/forecast?latitude=52.52&longitude=13.41&current=temperature_2m,wind_speed_10m&hourly=temperature_2m,relative_humidity_2m,wind_speed_10m';
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Open-Meteo API returned status ${response.status}`);
        }

        const data = await response.json();

        const itemId = uuidv4();

        const dynamoItem = {
            TableName: tableName,
            Item: {
                id: { S: itemId },
                forecast: {
                    M: {
                        elevation: { N: String(data.elevation) },
                        generationtime_ms: { N: String(data.generationtime_ms) },
                        latitude: { N: String(data.latitude) },
                        longitude: { N: String(data.longitude) },
                        timezone: { S: data.timezone },
                        timezone_abbreviation: { S: data.timezone_abbreviation },
                        utc_offset_seconds: { N: String(data.utc_offset_seconds) },
                        hourly: {
                            M: {
                                temperature_2m: {
                                    L: data.hourly.temperature_2m.map((temp) => ({ N: String(temp) }))
                                },
                                time: {
                                    L: data.hourly.time.map((t) => ({ S: t }))
                                }
                            }
                        },
                        hourly_units: {
                            M: {
                                temperature_2m: { S: data.hourly_units.temperature_2m },
                                time: { S: data.hourly_units.time }
                            }
                        }
                    }
                }
            }
        };

        await ddb.putItem(dynamoItem).promise();

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Weather forecast saved successfully',
                id: itemId
            }),
            headers: {
                'Content-Type': 'application/json'
            }
        };
    } catch (error) {
        console.error('Error in Lambda:', error);

        return {
            statusCode: 500,
            body: JSON.stringify({
                error: error.message || 'Internal Server Error'
            }),
            headers: {
                'Content-Type': 'application/json'
            }
        };
    }
};
